export interface HomeSkill {
  id: string;
  label: string;
  skillPath: string;
  description: string;
  prompt: string;
}

/** Homepage quick actions mapped to project Cursor skills. */
export const HOME_SKILLS: HomeSkill[] = [
  {
    id: 'chat',
    label: 'Smart Chat',
    skillPath: '.cursor/skills/smart-chat/SKILL.md',
    description: 'General coding conversation with context from the workspace and selection.',
    prompt: '',
  },
  {
    id: 'generate',
    label: 'Code Generation',
    skillPath: '.cursor/skills/code-generation/SKILL.md',
    description: 'Generate new code that matches project conventions.',
    prompt:
      'Follow the workflow in .cursor/skills/code-generation/SKILL.md.\n\n' +
      'Generate code for the task below. Match existing project conventions, types, and imports. ' +
      'Prefer editing or creating the smallest set of files needed.\n\nTask: ',
  },
  {
    id: 'review',
    label: 'Code Review',
    skillPath: '.cursor/skills/code-review/SKILL.md',
    description: 'Structured review of selected or open code.',
    prompt:
      'Follow the workflow in .cursor/skills/code-review/SKILL.md.\n\n' +
      'Review the selected code (or the files I have open) and report findings using the skill output format.',
  },
  {
    id: 'explain',
    label: 'Explain Code',
    skillPath: '.cursor/skills/explain-code/SKILL.md',
    description: 'Plain-language explanation of how code works.',
    prompt:
      'Follow the workflow in .cursor/skills/explain-code/SKILL.md.\n\n' +
      'Explain the selected code (or the files I have open) for a developer on this codebase.',
  },
  {
    id: 'tests',
    label: 'Generate Tests',
    skillPath: '.cursor/skills/generate-tests/SKILL.md',
    description: 'Unit tests aligned with project test stack.',
    prompt:
      'Follow the workflow in .cursor/skills/generate-tests/SKILL.md.\n\n' +
      'Generate tests for the selected code (or the files I have open). Use the project’s existing test framework and patterns.',
  },
  {
    id: 'docs',
    label: 'Document Generation',
    skillPath: '.cursor/skills/document-generation/SKILL.md',
    description: 'Documentation and inline comments for APIs and modules.',
    prompt:
      'Follow the workflow in .cursor/skills/document-generation/SKILL.md.\n\n' +
      'Generate documentation for the selected code (or the files I have open). Match the project’s doc style.',
  },
];

export function homeSkillById(id: string): HomeSkill | undefined {
  return HOME_SKILLS.find(s => s.id === id);
}
