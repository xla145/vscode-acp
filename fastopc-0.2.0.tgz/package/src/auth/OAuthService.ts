import * as crypto from 'crypto';
import * as vscode from 'vscode';
import { log, logError } from '../utils/Logger';

/** Supported OAuth identity providers. */
export type OAuthProvider = 'github' | 'microsoft' | 'google';

/** Persisted user profile (no secrets — tokens stay in VS Code / SecretStorage). */
export interface UserProfile {
  provider: OAuthProvider;
  id: string;
  displayName: string;
  email?: string;
  avatarInitials: string;
}

interface PendingGoogleAuth {
  state: string;
  codeVerifier: string;
  resolve: (profile: UserProfile) => void;
  reject: (err: Error) => void;
}

const PROFILE_KEY = 'fastopc.auth.profile';

function initialsFromName(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length >= 2) {
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }
  return (name.slice(0, 2) || 'U').toUpperCase();
}

/**
 * OAuth sign-in for Fast OPC.
 *
 * - **GitHub / Microsoft** — VS Code built-in Authentication API (browser OAuth handled by the IDE).
 * - **Google** — Authorization Code + PKCE, callback via {@link registerUriHandler}.
 */
export class OAuthService implements vscode.UriHandler {
  private profile: UserProfile | null = null;
  private pendingGoogle: PendingGoogleAuth | null = null;
  private readonly onDidChangeProfileEmitter = new vscode.EventEmitter<UserProfile | null>();
  readonly onDidChangeProfile = this.onDidChangeProfileEmitter.event;

  constructor(private readonly context: vscode.ExtensionContext) {
    const saved = context.globalState.get<UserProfile>(PROFILE_KEY);
    if (saved?.provider && saved.id && saved.displayName) {
      this.profile = saved;
    }
  }

  /** Whether the login gate should block the chat UI. */
  isLoginRequired(): boolean {
    return vscode.workspace.getConfiguration('acp').get<boolean>('auth.requireLogin', true);
  }

  getProfile(): UserProfile | null {
    return this.profile;
  }

  isAuthenticated(): boolean {
    if (!this.isLoginRequired()) {
      return true;
    }
    return this.profile !== null;
  }

  /** Register vscode:// callback for Google OAuth. */
  register(context: vscode.ExtensionContext): void {
    context.subscriptions.push(vscode.window.registerUriHandler(this));
  }

  async handleUri(uri: vscode.Uri): Promise<void> {
    if (uri.path !== '/oauth/google') {
      return;
    }
    const params = new URLSearchParams(uri.query);
    const error = params.get('error');
    const pending = this.pendingGoogle;
    this.pendingGoogle = null;

    if (!pending) {
      vscode.window.showWarningMessage('OAuth callback received with no pending sign-in.');
      return;
    }

    if (error) {
      pending.reject(new Error(error));
      return;
    }

    const code = params.get('code');
    const state = params.get('state');
    if (!code || state !== pending.state) {
      pending.reject(new Error('Invalid OAuth callback.'));
      return;
    }

    try {
      const profile = await this.exchangeGoogleCode(code, pending.codeVerifier);
      await this.setProfile(profile);
      pending.resolve(profile);
    } catch (e: any) {
      logError('Google OAuth failed', e);
      pending.reject(e instanceof Error ? e : new Error(String(e)));
    }
  }

  async signIn(provider: OAuthProvider): Promise<UserProfile> {
    let profile: UserProfile;
    switch (provider) {
      case 'github':
        profile = await this.signInGitHub();
        break;
      case 'microsoft':
        profile = await this.signInMicrosoft();
        break;
      case 'google':
        profile = await this.signInGoogle();
        break;
      default:
        throw new Error(`Unsupported provider: ${provider}`);
    }
    await this.setProfile(profile);
    return profile;
  }

  async signOut(): Promise<void> {
    await this.setProfile(null);
  }

  private async setProfile(profile: UserProfile | null): Promise<void> {
    this.profile = profile;
    await this.context.globalState.update(PROFILE_KEY, profile);
    this.onDidChangeProfileEmitter.fire(profile);
  }

  private async signInGitHub(): Promise<UserProfile> {
    const session = await vscode.authentication.getSession(
      'github',
      ['read:user', 'user:email'],
      { createIfNone: true },
    );

    let email: string | undefined;
    let displayName = session.account.label;

    try {
      const res = await fetch('https://api.github.com/user', {
        headers: {
          Authorization: `Bearer ${session.accessToken}`,
          Accept: 'application/vnd.github+json',
          'User-Agent': 'fastopc-vscode',
        },
      });
      if (res.ok) {
        const data = await res.json() as { name?: string; login?: string; email?: string };
        displayName = data.name || data.login || displayName;
        email = data.email || email;
      }
      if (!email) {
        const emailRes = await fetch('https://api.github.com/user/emails', {
          headers: {
            Authorization: `Bearer ${session.accessToken}`,
            Accept: 'application/vnd.github+json',
            'User-Agent': 'fastopc-vscode',
          },
        });
        if (emailRes.ok) {
          const emails = await emailRes.json() as Array<{ email: string; primary?: boolean }>;
          const primary = emails.find(e => e.primary) || emails[0];
          email = primary?.email;
        }
      }
    } catch (e) {
      logError('GitHub user info fetch failed', e);
    }

    return {
      provider: 'github',
      id: session.account.id,
      displayName,
      email,
      avatarInitials: initialsFromName(displayName),
    };
  }

  private async signInMicrosoft(): Promise<UserProfile> {
    const session = await vscode.authentication.getSession(
      'microsoft',
      ['openid', 'profile', 'email', 'User.Read'],
      { createIfNone: true },
    );

    let displayName = session.account.label;
    let email: string | undefined;

    try {
      const res = await fetch('https://graph.microsoft.com/v1.0/me', {
        headers: { Authorization: `Bearer ${session.accessToken}` },
      });
      if (res.ok) {
        const data = await res.json() as { displayName?: string; mail?: string; userPrincipalName?: string };
        displayName = data.displayName || displayName;
        email = data.mail || data.userPrincipalName;
      }
    } catch (e) {
      logError('Microsoft Graph user info fetch failed', e);
    }

    return {
      provider: 'microsoft',
      id: session.account.id,
      displayName,
      email,
      avatarInitials: initialsFromName(displayName),
    };
  }

  private async signInGoogle(): Promise<UserProfile> {
    const clientId = vscode.workspace.getConfiguration('acp').get<string>('oauth.googleClientId', '').trim();
    if (!clientId) {
      throw new Error(
        'Google Sign-In is not configured. Set "acp.oauth.googleClientId" in Settings.',
      );
    }

    if (this.pendingGoogle) {
      throw new Error('A Google sign-in is already in progress.');
    }

    const codeVerifier = crypto.randomBytes(32).toString('base64url');
    const codeChallenge = crypto
      .createHash('sha256')
      .update(codeVerifier)
      .digest('base64url');
    const state = crypto.randomBytes(16).toString('hex');

    const redirectUri = this.googleRedirectUri();
    const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
    authUrl.searchParams.set('client_id', clientId);
    authUrl.searchParams.set('redirect_uri', redirectUri);
    authUrl.searchParams.set('response_type', 'code');
    authUrl.searchParams.set('scope', 'openid email profile');
    authUrl.searchParams.set('state', state);
    authUrl.searchParams.set('code_challenge', codeChallenge);
    authUrl.searchParams.set('code_challenge_method', 'S256');
    authUrl.searchParams.set('access_type', 'offline');
    authUrl.searchParams.set('prompt', 'consent');

    const profilePromise = new Promise<UserProfile>((resolve, reject) => {
      this.pendingGoogle = { state, codeVerifier, resolve, reject };
    });

    log(`Opening Google OAuth: redirect=${redirectUri}`);
    await vscode.env.openExternal(vscode.Uri.parse(authUrl.toString()));

    const timeoutMs = 120_000;
    const timeout = new Promise<never>((_, reject) => {
      setTimeout(() => {
        if (this.pendingGoogle?.state === state) {
          this.pendingGoogle = null;
          reject(new Error('Google sign-in timed out. Please try again.'));
        }
      }, timeoutMs);
    });

    return Promise.race([profilePromise, timeout]);
  }

  private googleRedirectUri(): string {
    const publisher = this.context.extension.packageJSON.publisher as string;
    const name = this.context.extension.packageJSON.name as string;
    return `vscode://${publisher}.${name}/oauth/google`;
  }

  private async exchangeGoogleCode(code: string, codeVerifier: string): Promise<UserProfile> {
    const clientId = vscode.workspace.getConfiguration('acp').get<string>('oauth.googleClientId', '').trim();
    const redirectUri = this.googleRedirectUri();

    const body = new URLSearchParams({
      client_id: clientId,
      code,
      code_verifier: codeVerifier,
      grant_type: 'authorization_code',
      redirect_uri: redirectUri,
    });

    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString(),
    });

    if (!tokenRes.ok) {
      const errText = await tokenRes.text();
      throw new Error(`Google token exchange failed: ${errText}`);
    }

    const tokens = await tokenRes.json() as { access_token: string };
    const userRes = await fetch('https://openidconnect.googleapis.com/v1/userinfo', {
      headers: { Authorization: `Bearer ${tokens.access_token}` },
    });

    if (!userRes.ok) {
      throw new Error('Failed to fetch Google user profile.');
    }

    const user = await userRes.json() as { sub: string; name?: string; email?: string };
    const displayName = user.name || user.email || 'Google User';

    return {
      provider: 'google',
      id: user.sub,
      displayName,
      email: user.email,
      avatarInitials: initialsFromName(displayName),
    };
  }
}
