# quchi-platform-sdk-ts 对接文档

TypeScript SDK，用于接入 Quchi 平台的认证与 AI 能力。

---

## 目录

1. [安装](#安装)
2. [客户端初始化](#客户端初始化)
3. [方法说明](#方法说明)
4. [阶段一：设备认证（Device Flow）](#阶段一设备认证device-flow)
5. [阶段二：Token 管理](#阶段二token-管理)
6. [阶段三：模型与对话](#阶段三模型与对话)
7. [完整示例](#完整示例)

---

## 安装

### 从内部 npm 快照仓库

```bash
npm config set registry https://maven.internal.quchiai.com/repository/npm-snapshots/
npm install quchi-platform-sdk-ts
```

### 在 pnpm workspace / 本地开发

```bash
pnpm add quchi-platform-sdk-ts
```

---

## 客户端初始化

```ts
import { QuchibhClient, extractContent } from 'quchi-platform-sdk-ts'

const client = new QuchibhClient({
  platformUrl: 'https://www.quchiai.com',
  clientId: 'opc-work',
  clientSecret: 'GObe_gpC-cPgL8opc8gmvonGqM-gma4Jv9gSXepdbsY',
})
```

**构造参数：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `platformUrl` | `string` | Quchi 平台地址 |
| `clientId` | `string` | 应用标识 |
| `clientSecret` | `string` | 应用密钥 |

---

## 方法说明

### `client.requestDeviceCode(scope)`

向平台申请设备码，启动 Device Flow 认证。

```ts
const device = await client.requestDeviceCode('api:workspace.read')
```

**参数：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `scope` | `string` | 权限范围，如 `api:workspace.read` |

**返回值 `DeviceCodeResponse`：**

| 字段 | 类型 | 说明 |
|------|------|------|
| `deviceCode` | `string` | 设备码，用于后续轮询（不展示给用户） |
| `userCode` | `string` | 用户码，需展示给用户在浏览器输入 |
| `verificationUri` | `string` | 用户需要打开的验证页面 URL |
| `interval` | `number` | 轮询间隔（秒） |
| `expiresIn` | `number` | 设备码有效期（秒） |

---

### `client.pollDeviceToken(deviceCode)`

轮询设备码是否已完成授权，返回 Token 或 `null`（未完成时）。

```ts
const token = await client.pollDeviceToken(device.deviceCode)
```

**参数：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `deviceCode` | `string` | 由 `requestDeviceCode` 返回的设备码 |

**返回值 `TokenResponse | null`：**

| 字段 | 类型 | 说明 |
|------|------|------|
| `accessToken` | `string` | 访问令牌，用于 API 请求 |
| `refreshToken` | `string` | 刷新令牌，用于续期 |
| `expiresIn` | `number` | access token 有效期（秒） |

> 用户尚未完成授权时返回 `null`，需要继续轮询。

---

### `client.refreshToken(refreshToken)`

使用 refresh token 换取新的 access token。

```ts
const newToken = await client.refreshToken(token.refreshToken)
```

**参数：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `refreshToken` | `string` | 由 `pollDeviceToken` 返回的刷新令牌 |

**返回值 `TokenResponse`：** 同 `pollDeviceToken` 返回结构。

---

### `client.createTokenManager(token, onRefresh, options?)`

创建自动 Token 刷新管理器，在 access token 过期前自动续期。

```ts
const manager = client.createTokenManager(
  token,
  (newToken) => {
    saveTokenToStorage(newToken)
  },
  { refreshBeforeMs: 5 * 60 * 1000 },
)
```

**参数：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `token` | `TokenResponse` | 初始 Token |
| `onRefresh` | `(newToken: TokenResponse) => void` | 刷新成功后的回调，用于持久化新 Token |
| `options.refreshBeforeMs` | `number` | 提前多少毫秒刷新，默认 `5 * 60 * 1000`（5 分钟） |

**返回值 `TokenManager`：**

| 方法 | 说明 |
|------|------|
| `stop()` | 停止自动刷新，清理定时器（程序退出前调用） |

---

### `client.getDefaultModels(accessToken)`

获取平台为当前用户分配的默认可用模型列表。

```ts
const models = await client.getDefaultModels(token.accessToken)
```

**参数：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `accessToken` | `string` | 有效的访问令牌 |

**返回值 `Model[]`：**

| 字段 | 类型 | 说明 |
|------|------|------|
| `modelId` | `string` | 模型标识，传入 `chatCompletions` |
| `name` | `string` | 模型名称（展示用） |

---

### `client.chatCompletions(accessToken, modelId, messages)`

发起流式对话请求，返回异步迭代器，逐块接收响应内容。

```ts
for await (const chunk of client.chatCompletions(
  token.accessToken,
  models[0]?.modelId ?? 'gpt-4o-mini',
  [{ role: 'user', content: '你好' }],
)) {
  const text = extractContent(chunk)
  if (text) process.stdout.write(text)
}
```

**参数：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `accessToken` | `string` | 有效的访问令牌 |
| `modelId` | `string` | 目标模型 ID |
| `messages` | `Message[]` | 对话消息列表，格式同 OpenAI Chat |

**`Message` 结构：**

| 字段 | 类型 | 说明 |
|------|------|------|
| `role` | `'user' \| 'assistant' \| 'system'` | 消息角色 |
| `content` | `string` | 消息内容 |

**返回值：** `AsyncIterable<Chunk>`，每次迭代返回一个 SSE 数据块。

---

### `extractContent(chunk)`

工具函数，从 SSE 数据块中提取文本内容。

```ts
import { extractContent } from 'quchi-platform-sdk-ts'

const text = extractContent(chunk)
```

**参数：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `chunk` | `Chunk` | 来自 `chatCompletions` 的单个数据块 |

**返回值：** `string | null`，有内容时为文本字符串，否则为 `null`（如心跳帧、`[DONE]` 帧）。

---

## 阶段一：设备认证（Device Flow）

适用场景：桌面程序、CLI、本地脚本等**无法提供回调地址**的场景。

### 流程说明

1. 调用 `requestDeviceCode` 获取设备码和用户码
2. 将验证 URL 和用户码展示给用户
3. 用户在浏览器打开 URL，输入用户码，完成授权
4. 程序按 `interval` 间隔轮询 `pollDeviceToken`
5. 授权完成后获取 `accessToken` 和 `refreshToken`

```
┌──────────────────────────────────────────────────────────────┐
│                   阶段一：设备认证流程                         │
└──────────────────────────────────────────────────────────────┘

  程序                          平台                    用户/浏览器
   │                             │                          │
   │─── requestDeviceCode ──────>│                          │
   │<── { deviceCode,            │                          │
   │      userCode,              │                          │
   │      verificationUri,       │                          │
   │      interval }             │                          │
   │                             │                          │
   │──── 展示 verificationUri + userCode ─────────────────>│
   │                             │<── 用户打开 URL 输入码 ──│
   │                             │<── 授权确认 ─────────────│
   │                             │                          │
   │─ pollDeviceToken (每 interval 秒) ─>│                  │
   │<── null（未完成）           │                          │
   │         ...重复轮询...      │                          │
   │─── pollDeviceToken ────────>│                          │
   │<── { accessToken,           │                          │
   │      refreshToken,          │                          │
   │      expiresIn }            │                          │
```

### 代码示例

```ts
const device = await client.requestDeviceCode('api:workspace.read')

console.log('请在浏览器打开:', device.verificationUri)
console.log('并输入用户码:', device.userCode)

let token = null
while (!token) {
  await new Promise((resolve) => setTimeout(resolve, device.interval * 1000))
  token = await client.pollDeviceToken(device.deviceCode)
}

console.log('accessToken:', token.accessToken)
```

---

## 阶段二：Token 管理

### Token 有效期

| Token 类型 | 有效期 |
|-----------|--------|
| access token | 1 小时 |
| refresh token | 7 天 |

### 手动刷新

access token 过期后，使用 refresh token 换取新 token：

```ts
const newToken = await client.refreshToken(token.refreshToken)
console.log('新 accessToken:', newToken.accessToken)
```

### 自动刷新（推荐）

`createTokenManager` 在 access token 过期前自动刷新，适合长时间运行的程序：

```ts
const manager = client.createTokenManager(
  token,
  (newToken) => {
    // 每次自动刷新后回调，保存新 token
    saveTokenToStorage(newToken)
  },
  { refreshBeforeMs: 5 * 60 * 1000 }, // 提前 5 分钟刷新（默认值）
)

// 程序退出时清理定时器
manager.stop()
```

### Token 生命周期说明

```
获取 token
    │
    ▼
access token 有效（1小时）
    │
    │  （到期前 5 分钟）
    ▼
自动调用 refreshToken
    │
    ├── 成功 ──> 回调 onRefresh，保存新 token，重置计时器
    │
    └── refresh token 也过期（7天后）──> 需重新走设备认证流程
```

---

## 阶段三：模型与对话

mode 目前只支持 标准 和 旗舰 

### 流式对话

`chatCompletions` 返回 SSE 流，通过 `for await` 逐块处理：

```ts
for await (const chunk of client.chatCompletions(
  token.accessToken,
  mode,
  [
    { role: 'system', content: '你是一个有帮助的助手' },
    { role: 'user', content: '你好' },
  ],
)) {
  const text = extractContent(chunk)
  if (text) process.stdout.write(text)
}
```

### 流式响应处理说明

```
chatCompletions 返回 AsyncIterable<Chunk>
         │
         │  for await (const chunk of ...)
         ▼
   ┌─────────────┐
   │  extractContent(chunk)  │
   └─────────────┘
         │
    ┌────┴────┐
    │         │
  string    null
    │         │
  输出文本   跳过（心跳帧 / [DONE]）
```

---

## 完整示例

以下示例展示了从认证到对话的完整流程：

```ts
import { QuchibhClient, extractContent } from 'quchi-platform-sdk-ts'

// 1. 初始化客户端
const client = new QuchibhClient({
  platformUrl: 'https://www.quchiai.com',
  clientId: 'opc-work',
  clientSecret: 'GObe_gpC-cPgL8opc8gmvonGqM-gma4Jv9gSXepdbsY',
})

// 2. 设备认证
const device = await client.requestDeviceCode('api:workspace.read')
console.log('请在浏览器打开:', device.verificationUri)
console.log('并输入用户码:', device.userCode)

let token = null
while (!token) {
  await new Promise((resolve) => setTimeout(resolve, device.interval * 1000))
  token = await client.pollDeviceToken(device.deviceCode)
}

// 3. 启动自动 Token 刷新
const manager = client.createTokenManager(
  token,
  (newToken) => {
    token = newToken
    saveTokenToStorage(newToken) // 持久化 token
  },
)

mode: 

// 5. 流式对话
for await (const chunk of client.chatCompletions(
  token.accessToken,
  mode,
  [{ role: 'user', content: '你好' }],
)) {
  const text = extractContent(chunk)
  if (text) process.stdout.write(text)
}

// 6. 程序退出时清理
manager.stop()
```
